﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp2
{
    public partial class Form2 : Form
    {
        DBConnect liga = new DBConnect();
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num_mecanografico = 0;

            if (textBox1.Text != "") { num_mecanografico = Convert.ToInt32(textBox1.Text); }
                       
            string nome_colaborador = textBox2.Text;
            string data_nasc = textBox3.Text;
            string data_admissao = textBox4.Text;

            DataTable dt = new DataTable();
            dt = liga.Consulta_select(num_mecanografico,nome_colaborador,data_nasc,data_admissao);
            dataGridView1.DataSource = dt; 
        }

    }
}
