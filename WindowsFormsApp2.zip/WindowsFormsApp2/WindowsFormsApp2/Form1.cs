﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        DBConnect liga = new DBConnect();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 Obj = new Form2();
            Obj.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int num_meca = 0;
            string nome = "";
            string data_nasc = "";
            string data_adm = "";

            num_meca = Convert.ToInt32(textBox1.Text);
            nome = textBox2.Text;
            data_nasc = textBox3.Text;
            data_adm = textBox4.Text;

            if (liga.Inserir(num_meca, nome, data_nasc, data_adm)) 
            { 
                label5.Text = "Inserido com sucesso";
            }
            else
            {
                label5.Text = "Erro na inserção!";
            }
        }
    }
}
