﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Org.BouncyCastle.Crypto.Digests;

namespace WindowsFormsApp2
{
    //internal class DBConnect
    internal class DBConnect
    {
        private SqlConnection connection;

        private string server;
        private string database;
        private string uid;
        private string password;


        public DBConnect()
        {
            Initialize();
        }

        private void Initialize()
        {
            string connectionString;
            server = @"tesla\ead";
            database = "TESTE";


            connectionString = "Server=" + server + ";Database=" + database + ";Integrated Security = True";
            connection = new SqlConnection(connectionString);
        }

        public bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (SqlException e)
            {
                Console.WriteLine(e);
                return false;
            }
        }
        public bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (SqlException e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public bool Inserir(int num, string nome, string data_nasc, string data_adm)
        {
            string query = "Exec Inserir " + num + ",'" + nome + "','" + data_nasc + "','" + data_adm + "';";
            if (OpenConnection())
            {
                try
                {
                    SqlCommand cmd = new SqlCommand("Inserir", connection);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("num_mec", num);
                    cmd.Parameters.AddWithValue("nome_colab", nome);
                    cmd.Parameters.AddWithValue("data_nasc", data_nasc);
                    cmd.Parameters.AddWithValue("data_admissao", data_adm);
                    cmd.ExecuteNonQuery();
                    CloseConnection();
                    return true;

                }
                catch (SqlException e)
                {
                    return false;
                }
            }
            else
            {
                return false;
            }

        }
   
        public DataTable Consulta_select(int num_mec, string nome_colab, string data_nasc, string data_adm)
        {
            if (OpenConnection())
            {
                SqlCommand cmd = new SqlCommand("Consulta", connection);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("num_mecanografico", num_mec);
                cmd.Parameters.AddWithValue("nome_colab", nome_colab);
                cmd.Parameters.AddWithValue("data_nasc", data_nasc);
                cmd.Parameters.AddWithValue("data_admissao", data_adm);
                cmd.ExecuteNonQuery();

                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                CloseConnection();
                return ds.Tables[0];
            }
            else
            {
                Console.WriteLine("Erro!!!");
                return null;
            }

        }
    }       
}







